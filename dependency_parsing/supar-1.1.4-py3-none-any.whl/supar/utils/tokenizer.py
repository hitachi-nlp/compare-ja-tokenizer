# -*- coding: utf-8 -*-

from __future__ import annotations

import os
import re
import tempfile
from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional, Union

import torch.distributed as dist
from supar.utils.parallel import is_master
from supar.utils.vocab import Vocab


##### Added to consider a pre-tokenizer
from typing import Optional
import textspan
import traceback
import mojimoji
from pyknp import Juman
from MeCab import Tagger
import vaporetto
from sudachipy import tokenizer
from sudachipy import dictionary
from tokenizers import NormalizedString, PreTokenizedString

class MecabPreTokenizer:
    def __init__(self, mecab_dict_path: Optional[str] = None):
        mecab_option = (f"-Owakati -d {mecab_dict_path}" if mecab_dict_path is not None else "-Owakati")
        self.mecab = Tagger(mecab_option)
    
    def tokenize(self, sequence: str) -> list[str]:
        #return self.mecab.parse(mojimoji.han_to_zen(sequence)).strip().split(" ")
        return self.mecab.parse(sequence).strip().split(" ")
    
    def custom_split(self, i: int, normalized_string: NormalizedString) -> list[NormalizedString]:
        text = str(normalized_string)
        tokens = self.tokenize(text)
        tokens_spans = textspan.get_original_spans(tokens, text)
        return [normalized_string[st:ed] for cahr_spans in tokens_spans for st,ed in cahr_spans]
    
    def pre_tokenize(self, pretok: PreTokenizedString):
        pretok.split(self.custom_split)


class JumanPreTokenizer:
    def __init__(self):
        self.juman = Juman("jumanpp", multithreading=True)
    
    def tokenize(self, sequence: str) -> list[str]:
        text = mojimoji.han_to_zen(sequence).rstrip()
        try:
            result = self.juman.analysis(text)
        except:
            traceback.print_exc()
            text = ""
            result = self.juman.analysis(text)
        return [mrph.midasi for mrph in result.mrph_list()]
    
    def custom_split(self, i: int, normalized_string: NormalizedString) -> list[NormalizedString]:
        text = str(normalized_string)
        tokens = self.tokenize(text)
        tokens_spans = textspan.get_original_spans(tokens, text)
        return [normalized_string[st:ed] for cahr_spans in tokens_spans for st,ed in cahr_spans]
    
    def pre_tokenize(self, pretok: PreTokenizedString):
        pretok.split(self.custom_split)


class VaporettoPreTokenizer:
    def __init__(self, unidic_path: str):
        with open(unidic_path, 'rb') as fp:
            model = fp.read()
        self.tokenizer = vaporetto.Vaporetto(model, predict_tags=False)
    
    def tokenize(self, sequence: str) -> list[str]:
        tokens = self.tokenizer.tokenize(sequence)
        return [token.surface() for token in tokens]
    
    def custom_split(self, i: int, normalized_string: NormalizedString) -> list[NormalizedString]:
        text = str(normalized_string)
        tokens = self.tokenize(text)
        tokens_spans = textspan.get_original_spans(tokens, text)
        return [normalized_string[st:ed] for cahr_spans in tokens_spans for st,ed in cahr_spans]
    
    def pre_tokenize(self, pretok: PreTokenizedString):
        pretok.split(self.custom_split)


class SudachiPreTokenizer:
    def __init__(self):
        self.sudachi = tokenizer_obj = dictionary.Dictionary().create()
    
    def tokenize(self, sequence: str) -> list[str]:
        return [token.surface() for token in self.sudachi.tokenize(sequence)]
    
    def custom_split(self, i: int, normalized_string: NormalizedString) -> list[NormalizedString]:
        text = str(normalized_string)
        tokens = self.tokenize(text)
        tokens_spans = textspan.get_original_spans(tokens, text)
        return [normalized_string[st:ed] for cahr_spans in tokens_spans for st,ed in cahr_spans]
    
    def pre_tokenize(self, pretok: PreTokenizedString):
        pretok.split(self.custom_split)
######


class Tokenizer:

    def __init__(self, lang: str = 'en') -> Tokenizer:
        import stanza
        try:
            self.pipeline = stanza.Pipeline(lang=lang, processors='tokenize', verbose=False, tokenize_no_ssplit=True)
        except Exception:
            stanza.download(lang=lang, resources_url='stanford')
            self.pipeline = stanza.Pipeline(lang=lang, processors='tokenize', verbose=False, tokenize_no_ssplit=True)

    def __call__(self, text: str) -> List[str]:
        return [i.text for i in self.pipeline(text).sentences[0].tokens]


class TransformerTokenizer:

    def __init__(self, name, **kwargs) -> TransformerTokenizer:
        from transformers import AutoTokenizer
        self.name = name
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(name, local_files_only=True)
        except Exception:
            try:
                self.tokenizer = AutoTokenizer.from_pretrained(name, local_files_only=False)
            except Exception:
                from tokenizers import Tokenizer as HFTokenizer
                from tokenizers.pre_tokenizers import PreTokenizer
                from tokenizers.processors import BertProcessing
                from transformers import  PreTrainedTokenizerFast
                tokenizer = HFTokenizer.from_file(kwargs["bert_tokenizer_file"])
                tokenizer.post_processor = BertProcessing(
                    cls=("[CLS]", tokenizer.token_to_id('[CLS]')),
                    sep=("[SEP]", tokenizer.token_to_id('[SEP]'))
                )
                tokenizer = PreTrainedTokenizerFast(
                    tokenizer_object=tokenizer,
                    unk_token='[UNK]',
                    cls_token='[CLS]',
                    sep_token = '[SEP]',
                    pad_token='[PAD]',
                    mask_token='[MASK]'
                )
                if kwargs["pretokenizer_type"] is not None:
                    if kwargs["pretokenizer_type"] == "mecab":
                        pre_tokenizer = MecabPreTokenizer(kwargs["mecab_dict_path"])
                    elif kwargs["pretokenizer_type"] == "juman":
                        pre_tokenizer = JumanPreTokenizer()
                    elif kwargs["pretokenizer_type"] == "vaporetto":
                        pre_tokenizer = VaporettoPreTokenizer(kwargs["unidic_path"])
                    elif kwargs["pretokenizer_type"] == "sudachi":
                        pre_tokenizer = SudachiPreTokenizer()
                    elif kwargs["pretokenizer_type"] == "nothing":
                        pre_tokenizer = None
                    else:
                        raise NotImplementedError()
                    if pre_tokenizer is not None:
                        tokenizer._tokenizer.pre_tokenizer = PreTokenizer.custom(pre_tokenizer)
                self.tokenizer = tokenizer

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.name})"

    def __len__(self) -> int:
        return self.vocab_size

    def __call__(self, text: str) -> List[str]:
        from transformers import GPT2Tokenizer, GPT2TokenizerFast
        if isinstance(self.tokenizer, (GPT2Tokenizer, GPT2TokenizerFast)):
            text = ' ' + text
        return self.tokenizer.tokenize(text)

    def __getattr__(self, name: str) -> Any:
        return getattr(self.tokenizer, name)

    def __getstate__(self) -> Dict:
        return self.__dict__

    def __setstate__(self, state: Dict):
        self.__dict__.update(state)

    @property
    def vocab(self):
        return defaultdict(lambda: self.tokenizer.vocab[self.unk], self.tokenizer.get_vocab())

    @property
    def vocab_size(self):
        return len(self.vocab)

    @property
    def pad(self):
        return self.tokenizer.pad_token

    @property
    def unk(self):
        return self.tokenizer.unk_token

    @property
    def bos(self):
        return self.tokenizer.bos_token or self.tokenizer.cls_token

    @property
    def eos(self):
        return self.tokenizer.eos_token or self.tokenizer.sep_token

    def decode(self, text: List) -> str:
        return self.tokenizer.decode(text, skip_special_tokens=True, clean_up_tokenization_spaces=False)


class BPETokenizer:

    def __init__(
        self,
        path: str = None,
        files: Optional[List[str]] = None,
        vocab_size: Optional[int] = 32000,
        min_freq: Optional[int] = 2,
        dropout: float = None,
        backend: str = 'huggingface',
        pad: Optional[str] = None,
        unk: Optional[str] = None,
        bos: Optional[str] = None,
        eos: Optional[str] = None,
    ) -> BPETokenizer:

        self.path = path
        self.files = files
        self.min_freq = min_freq
        self.dropout = dropout or .0
        self.backend = backend
        self.pad = pad
        self.unk = unk
        self.bos = bos
        self.eos = eos
        self.special_tokens = [i for i in [pad, unk, bos, eos] if i is not None]

        if backend == 'huggingface':
            from tokenizers import Tokenizer
            from tokenizers.decoders import BPEDecoder
            from tokenizers.models import BPE
            from tokenizers.pre_tokenizers import WhitespaceSplit
            from tokenizers.trainers import BpeTrainer
            path = os.path.join(path, 'tokenizer.json')
            if is_master() and not os.path.exists(path):
                # start to train a tokenizer from scratch
                self.tokenizer = Tokenizer(BPE(dropout=dropout, unk_token=unk))
                self.tokenizer.pre_tokenizer = WhitespaceSplit()
                self.tokenizer.decoder = BPEDecoder()
                self.tokenizer.train(files=files,
                                     trainer=BpeTrainer(vocab_size=vocab_size,
                                                        min_frequency=min_freq,
                                                        special_tokens=self.special_tokens,
                                                        end_of_word_suffix='</w>'))
                self.tokenizer.save(path)
            if dist.is_initialized():
                dist.barrier()
            self.tokenizer = Tokenizer.from_file(path)
            self.vocab = self.tokenizer.get_vocab()

        elif backend == 'subword-nmt':
            import argparse
            from argparse import Namespace

            from subword_nmt.apply_bpe import BPE, read_vocabulary
            from subword_nmt.learn_joint_bpe_and_vocab import \
                learn_joint_bpe_and_vocab
            fmerge = os.path.join(path, 'merge.txt')
            fvocab = os.path.join(path, 'vocab.txt')
            separator = '@@'
            if is_master() and (not os.path.exists(fmerge) or not os.path.exists(fvocab)):
                with tempfile.TemporaryDirectory() as ftemp:
                    fall = os.path.join(ftemp, 'fall')
                    with open(fall, 'w') as f:
                        for file in files:
                            with open(file) as fi:
                                f.write(fi.read())
                    learn_joint_bpe_and_vocab(Namespace(input=[argparse.FileType()(fall)],
                                                        output=argparse.FileType('w')(fmerge),
                                                        symbols=vocab_size,
                                                        separator=separator,
                                                        vocab=[argparse.FileType('w')(fvocab)],
                                                        min_frequency=min_freq,
                                                        total_symbols=False,
                                                        verbose=False,
                                                        num_workers=32))
            if dist.is_initialized():
                dist.barrier()
            self.tokenizer = BPE(codes=open(fmerge), separator=separator, vocab=read_vocabulary(open(fvocab), None))
            self.vocab = Vocab(counter=Counter(self.tokenizer.vocab),
                               specials=self.special_tokens,
                               unk_index=self.special_tokens.index(unk))
        else:
            raise ValueError(f'Unsupported backend: {backend} not in (huggingface, subword-nmt)')

    def __repr__(self) -> str:
        s = self.__class__.__name__ + f'({self.vocab_size}, min_freq={self.min_freq}'
        if self.dropout > 0:
            s += f", dropout={self.dropout}"
        s += f", backend={self.backend}"
        if self.pad is not None:
            s += f", pad={self.pad}"
        if self.unk is not None:
            s += f", unk={self.unk}"
        if self.bos is not None:
            s += f", bos={self.bos}"
        if self.eos is not None:
            s += f", eos={self.eos}"
        s += ')'
        return s

    def __len__(self) -> int:
        return self.vocab_size

    def __call__(self, text: Union[str, List]) -> List[str]:
        is_pretokenized = isinstance(text, list)
        if self.backend == 'huggingface':
            return self.tokenizer.encode(text, is_pretokenized=is_pretokenized).tokens
        else:
            if not is_pretokenized:
                text = text.split()
            return self.tokenizer.segment_tokens(text, dropout=self.dropout)

    @property
    def vocab_size(self):
        return len(self.vocab)

    def decode(self, text: List) -> str:
        if self.backend == 'huggingface':
            return self.tokenizer.decode(text)
        else:
            text = self.vocab[text]
            text = ' '.join([i for i in text if i not in self.special_tokens])
            return re.sub(f'({self.tokenizer.separator} )|({self.tokenizer.separator} ?$)', '', text)
